#include<fstream>
#include<iostream>
#include<string.h>

using namespace std;

int main()
{
    fstream fin("q3.txt");
    int count=0;
    char ch[20];
    while(fin)
    {
        fin>>ch;
        if(ch[0]=='e')
        count++;
    }
    cout<<"no. of words starting with 'e' = "<<count;
    fin.close();
    return 0;
}
