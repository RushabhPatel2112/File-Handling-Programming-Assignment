#include<fstream>
#include<iostream>
#include<string.h>

using namespace std;

int main()
{
    fstream fin("q1.txt");
    int count=0;
    char ch[20],c[20];
    strcpy(c,"the");
    while(fin)
    {
        fin>>ch;
        if(strcmp(ch,c)==0)
        count++;
    }
    cout<<"Occurrence of 'the' = "<<count;
    fin.close();
    return 0;
}
