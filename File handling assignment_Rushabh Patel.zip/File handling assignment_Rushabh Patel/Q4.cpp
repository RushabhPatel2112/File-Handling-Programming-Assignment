#include<fstream>
#include<iostream>
#include<string.h>

using namespace std;

int main()
{
    fstream fin("q4.txt");
    int count=0;
    char ch[20];
    while(fin)
    {
        fin>>ch;
        int l = strlen(ch);
        if(ch[l-1]=='s')
            count++;
    }
    cout<<"no. of words ending with 's' = "<<count;
    fin.close();
    return 0;
}
